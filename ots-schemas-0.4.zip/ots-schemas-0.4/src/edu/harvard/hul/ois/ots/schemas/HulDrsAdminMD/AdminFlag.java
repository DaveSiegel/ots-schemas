/* 
 * Copyright 2010 Harvard University Library
 * 
 * This file is part of OTS-Schemas.
 * 
 * OTS-Schemas is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * OTS-Schemas is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with OTS-Schemas.  If not, see <http://www.gnu.org/licenses/>.
 */
package edu.harvard.hul.ois.ots.schemas.HulDrsAdminMD;

import static javax.xml.stream.XMLStreamConstants.END_ELEMENT;
import static javax.xml.stream.XMLStreamConstants.START_ELEMENT;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import org.codehaus.staxmate.out.SMNamespace;
import org.codehaus.staxmate.out.SMOutputElement;

public class AdminFlag {
	
	public static enum FlagType {CORRUPTED,FORMAT_ID_CONFLICT,OBJECT_INVALID,VIRUS_INFECTED,FAILED_OBJECT_CREATION,INCORRECT_METADATA}
	
	private AdminFlagInstance current = null;
	private List<AdminFlagInstance> previousAdminFlags;	
	
	public class AdminFlagInstance extends VersionedElementAttributes {
		private FlagType flagType;
		private String flagNote;
		
		private void outputAdminFlagInstance(SMOutputElement parent, SMNamespace ns) throws XMLStreamException {
			SMOutputElement adminFlag = parent.addElement(ns, "adminFlag");
			outputVersionedAttributes(adminFlag);
			if(flagType != null) {
				adminFlag.addElementWithCharacters(ns, "flagType",flagType.toString());
			}
			if(flagNote != null) {
				adminFlag.addElementWithCharacters(ns, "flagNote",flagNote);
			}
		}

		public FlagType getFlagType() {
			return flagType;
		}

		public String getFlagNote() {
			return flagNote;
		}
		
	}

	public AdminFlag() {
		previousAdminFlags = new ArrayList<AdminFlagInstance>();
	}
	
	public AdminFlag(XMLStreamReader reader) throws XMLStreamException {
		this();
		parse(reader);
	}
	
	public AdminFlagInstance[] getPreviousAdminFlags() {
		int size = previousAdminFlags.size();
		AdminFlagInstance[] adminFlags = new AdminFlagInstance[size];
		for(int i=0;i<size;i++) {
			adminFlags[i] = previousAdminFlags.get(i);
		}
		return adminFlags;
	}
	
	public FlagType getFlagType() {
		return current.flagType;
	}
	
	public String getFlagNote() {
		return current.flagNote;
	}
		
	public Date getCreateDate() {
		return current.createDate;
	}
	
	public String getCreatingAgent() {
		return current.creatingAgent;
	}
	
	public String getStatus() {
		return current.status;
	}
	
	public void setAdminFlag(FlagType flagType, String flagNote, String agent) {
		//if adminFlag has already been set
		if(current != null) {
			//create a copy of the current access flag
			AdminFlagInstance previousAdminFlag = new AdminFlagInstance();
			previousAdminFlag.flagType = current.flagType;
			previousAdminFlag.flagNote = current.flagNote;
			previousAdminFlag.createDate = current.createDate;
			previousAdminFlag.creatingAgent = current.creatingAgent;
			previousAdminFlag.status = "superseded";
			previousAdminFlag.modAgent = agent;
			previousAdminFlag.modDate = new Date();
			
			//add previous access flag to list
			previousAdminFlags.add(previousAdminFlag);
		}
		else {
			current = new AdminFlagInstance();
			current.status = "current";
		}
		
		//set the current values
		current.flagType = flagType;
		current.flagNote = flagNote;
		current.creatingAgent = agent;
		current.createDate = new Date();

	}
	
	public void parse(XMLStreamReader reader) throws XMLStreamException {
		AdminFlagInstance flag = new AdminFlagInstance();
		flag.status = reader.getAttributeValue(null,"status");
		try {
			String d = reader.getAttributeValue(null,"createDate");
			if(d != null)
				flag.createDate = flag.sdf.parse(d);
		}
		catch (ParseException e) {
			throw new XMLStreamException("Invalid Date: "+reader.getAttributeValue(null,"createDate"));
		}
		try {
			String d = reader.getAttributeValue(null,"modDate");
			if(d != null) 
				flag.modDate = flag.sdf.parse(d);
		}
		catch (ParseException e) {
			throw new XMLStreamException("Invalid Date: "+reader.getAttributeValue(null,"modDate"));
		}
		
		flag.creatingAgent = reader.getAttributeValue(null,"creatingAgent");
		flag.modAgent = reader.getAttributeValue(null,"modAgent");

		int event = reader.getEventType();
		String localName = "";
		while(!(event == END_ELEMENT && localName.equals("adminFlag"))) {
			event = reader.next();
			switch(event) {
			case START_ELEMENT:
				localName = reader.getLocalName();
				if(localName.equals("flagType")) {
					flag.flagType = FlagType.valueOf(reader.getElementText());
				}
				else if(localName.equals("flagNote")) {
					flag.flagNote = reader.getElementText();
				}
				break;
			case END_ELEMENT:
				localName = reader.getLocalName();
				break;
			}
		}
		
		if(flag.status.equals("current")) {
			current = flag;
		}
		else {
			previousAdminFlags.add(flag);
		}
	}

	public void output(SMOutputElement parent, SMNamespace ns) throws XMLStreamException {
		//output current values
		if(current != null) {
			current.outputAdminFlagInstance(parent,ns);
		}
		//output previous values
		for(AdminFlagInstance flag : previousAdminFlags) {
			flag.outputAdminFlagInstance(parent,ns);
		}
	}
}
